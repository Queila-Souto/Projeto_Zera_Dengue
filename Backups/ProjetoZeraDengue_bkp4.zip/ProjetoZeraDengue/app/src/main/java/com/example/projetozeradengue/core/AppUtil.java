package com.example.projetozeradengue.core;

import android.content.Context;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projetozeradengue.view.activity.LoginActivity;

// os métodos e variáveis declaradas nessa classe devem ser público e estático.
public class AppUtil extends AppCompatActivity {
public static final String TAG="Projeto Zera Dengue";
    }

