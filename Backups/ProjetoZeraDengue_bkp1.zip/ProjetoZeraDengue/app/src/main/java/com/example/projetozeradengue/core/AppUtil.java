package com.example.projetozeradengue.core;public class AppUtil {
}
