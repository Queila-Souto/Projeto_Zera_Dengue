package com.example.projetozeradengue.model;

public class User {
    private String name;
    private String email;

    public User(String name,String bod, String email, String password ) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.bod = bod;
    }


    private String password;

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setBod(String bod) {
        this.bod = bod;
    }

    private String bod ;



    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getBod() {
        return bod;
    }



}
