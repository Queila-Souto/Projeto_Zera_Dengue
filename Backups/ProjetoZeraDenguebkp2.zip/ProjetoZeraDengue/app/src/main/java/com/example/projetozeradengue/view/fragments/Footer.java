package com.example.projetozeradengue.view.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projetozeradengue.R;
import com.example.projetozeradengue.view.activity.LoginActivity;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;


public class Footer extends Fragment implements View.OnClickListener {

    EditText mname,memail, mpassword, mbod;
    MaterialButton mbtn_save, mbtn_back;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        return inflater.inflate(R.layout.fragment_footer,container,false); }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        startingComponents();
        mbtn_back.setOnClickListener(this);
        mbtn_save.setOnClickListener(this);




    }

    private void startingComponents(){
        mbtn_save=getActivity().findViewById((R.id.btn_save));
        mbtn_back=getActivity().findViewById((R.id.btn_back));
        mbod = getActivity().findViewById(R.id.ed_date);
        mname = getActivity().findViewById(R.id.ed_name);



    }
        private void backActivity() {
        Intent intent = new Intent(getActivity().getApplicationContext(), LoginActivity.class);
        startActivity(intent); }


    private void SaveUserAuth() {
        memail = getActivity().findViewById(R.id.ed_email);
        mpassword = getActivity().findViewById(R.id.ed_password);
        String email = memail.getText().toString();
        String password = mpassword.getText().toString();

        FirebaseAuth newUser = FirebaseAuth.getInstance();
    newUser.createUserWithEmailAndPassword(email, password); //recuperar dadoss da fragment cadastro
        Toast.makeText(getActivity().getBaseContext(), "usuario cadastrado", Toast.LENGTH_LONG).show();

    }




    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back:
                backActivity();
                break;
            case R.id.btn_save:
                SaveUserAuth();
                backActivity();
                break;


            }
        }}


