package com.example.projetozeradengue.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.example.projetozeradengue.R;
import com.example.projetozeradengue.controller.ControllerUser;
import com.example.projetozeradengue.core.AppUtil;
import com.example.projetozeradengue.datamodel.UserDataModel;

public class Splash extends AppCompatActivity {
ProgressBar pb;
ImageView banner;
int time = 5000;
ControllerUser controllerUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        goToActivity();
        controllerUser = new ControllerUser(getApplicationContext());
        Log.d(AppUtil.TAG , "Splash: Objeto controller estanciado/ conectado");
    }

    private void goToActivity(){
    Handler handler = new Handler();
    handler.postDelayed(new Runnable() {
        @Override
        public void run() {
            Intent intent = new Intent(Splash.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
    },time);

    }


}