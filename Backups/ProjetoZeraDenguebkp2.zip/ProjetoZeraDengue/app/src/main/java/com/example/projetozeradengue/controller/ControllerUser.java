package com.example.projetozeradengue.controller;

import android.content.Context;
import android.nfc.Tag;
import android.util.Log;

import com.example.projetozeradengue.core.AppUtil;
import com.example.projetozeradengue.datasource.AppDatabase;
import com.example.projetozeradengue.model.User;

//A Classe ControllerUser extende AppDatabase, pois todas a comunicação com o BD será deita aqui,
// dentro da camada controller.
// Implementa a interface  Icrud para controlar as ações do bd(CRUD)
public class ControllerUser extends AppDatabase implements  ICrud<User>{
    //ContentValues = passar uma key e um valor

    public ControllerUser(Context context) {

        super(context);
        Log.d(AppUtil.TAG , "ControllerUser: Banco de dados conectado");

    }
    @Override
    public void create(User obj) {


    }

    @Override
    public void retrieve(User obj) {

    }

    @Override
    public void update(User obj) {

    }

    @Override
    public void delete(User obj) {

    }
}
