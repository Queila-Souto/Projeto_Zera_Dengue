package com.example.projetozeradengue.controller;

public interface ICrud<T> {
    public void create(T obj);
    public void retrieve(T obj);
    public void update(T obj);
    public void delete(T obj);

}
/*A interface contem metodos que serão obrigatóriamente implementados
nas classes a quem ela for atribuída. Nesse caso, usaremos a interface
para implementar o crud do banco de dados, por tanto, ela será atribuída
as nossas classes models.
C - CREATE - CRIAR / ADICIONAR;
R - RETRIEVE - RECUPERAR;
U - UPDATE - ATUALIZAR;
D - DELETE - EXCLUIR;

*/