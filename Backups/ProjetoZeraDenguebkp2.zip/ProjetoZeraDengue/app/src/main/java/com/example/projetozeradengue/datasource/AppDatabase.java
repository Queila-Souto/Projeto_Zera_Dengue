package com.example.projetozeradengue.datasource;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import androidx.annotation.Nullable;

import com.example.projetozeradengue.core.AppUtil;
import com.example.projetozeradengue.datamodel.UserDataModel;

import static com.example.projetozeradengue.core.AppUtil.TAG;

public class AppDatabase extends SQLiteOpenHelper {

    //MINHAS CONSTANTES
    private static final String DB_Name = "ZeraDengueDB.sqlite"; // atribuindo o nome do bd que desejo criar a uma String
    private static final int DB_VERSION = 1; // atribuindo o nome do bd que desejo criar a uma String
    SQLiteDatabase db;

    //construtor criado, solicitando apenas o contexto
    public AppDatabase(@Nullable Context context) {

        super(context, DB_Name, null, DB_VERSION);

        Log.d(TAG, "AppDatabase: Banco de dados Criado");

        db = getWritableDatabase(); // Abrindo o objeto database para escrita
    }


    @Override // MÉTODO PARA CRIAR O BANCO DE DADOS, UTILIZADO UMA UNICA VEZ
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(UserDataModel.createTable());
        Log.d(TAG, "onCreate: Tabela Usuarios criada "+ UserDataModel.createTable());

    }

    @Override // alterações no banco de dados.
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
